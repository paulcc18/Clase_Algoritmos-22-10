import { game } from "./fizzBuzzWhizz";

describe('FizzBuzz Game', () => {
  test('If the number is 1 return 1', () => {
    const result = game(1);
    expect(result).toEqual(1);
  });
  test('If the number is 2 return 2', () => {
    const result = game(2);
    expect(result).toEqual(2);
  });
  test('If the number is 3 return Fizz', () => {
    const result = game(3);
    expect(result).toEqual("Fizz");
  });
  test('If the number is 5 return Buzz', () => {
    const result = game(5);
    expect(result).toEqual("Buzz");
  });
  test('If the number is 15 return FizzBuzz', () => {
    const result = game(15);
    expect(result).toEqual("FizzBuzz"); 
  });
});